#include <iostream> //actividad 1 por Ricardo Martinez
 
int main()
{
    int edad; 
    //declaramos que la edad es un numero entero
    std::cout << "escriba su edad" << std::endl; 
    //escribimos en la pantalla 'escriba su edad'
    std::cin >> edad;
    //leemos el dato de la edad
    if (edad >= 18) {std::cout << "Eres mayor de edad" << std::endl;} 
    //condicionamos la mayoria de edad
    else {std::cout << "Eres menor de edad" << std::endl;}
    //condicionamos la minoria de edad
}