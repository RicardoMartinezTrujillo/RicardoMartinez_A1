#include <iostream>
#include <string>
#include <algorithm>
#include <cctype> //Actividad 3 realizado por Ricardo Martinez

int main ()

{

	std::string apmat,appat,snombre,pnombre,aC1o, aC1orfc, dia, mes, appl, apsl, aptl, apcl, apql, apv, apvd, aml, pnl, snl, nombrerfc,letras, letrasrfc;


	std::cout << "Ingresa tu nombre \nPrimer nombre: " << std::endl;
	std::cin >> pnombre;

	//Cuando el primer nombre es Jose o Maria, se utiliza el segundo nombre

	{
		if (pnombre== "jose") {
			std::cout << "Tu primer nombre es Jose\n\nIngresa tu segundo nombre\n\n(Si no tienes segundo nombre, vuelve a insertar el primero): " << std::endl;
			std::cin >> snombre;
		} else if (pnombre== "JOSE") {
			std::cout << "Tu primer nombre es Jose\nIngresa tu segundo nombre\n(Si no tienes segundo nombre, vuelve a insertar el primero): " << std::endl;
			std::cin >> snombre;
		} else if (pnombre== "Jose") {
			std::cout << "Tu primer nombre es Jose\nIngresa tu segundo nombre\n(Si no tienes segundo nombre, vuelve a insertar el primero): " << std::endl;
			std::cin >> snombre;
		} else if (pnombre== "J") {
			std::cout << "Tu primer nombre es Jose\nIngresa tu segundo nombre\n(Si no tienes segundo nombre, vuelve a insertar el primero): " << std::endl;
			std::cin >> snombre;
		} else if (pnombre== "j") {
			std::cout << "Tu primer nombre es Maria\nIngresa tu segundo nombre\n(Si no tienes segundo nombre, vuelve a insertar el primero): " << std::endl;
			std::cin >> snombre;
		} else {
			nombrerfc=pnl;
		}
	}

	std::cout << "Apellido Paterno: " << std::endl;
	std::cin >> appat;

	std::cout << "Apellido Materno \n\n(Si no cuentas con un apellido materno escribe 'X'): " << std::endl;
	std::cin >> apmat;

	std::cout << "Ingrese su fecha de nacimiento (Solo numeros) \nDia:" << std::endl;
	std::cin >> dia;

	std::cout << "Mes:" << std::endl;
	std::cin >> mes;

	std::cout << "AC1o:" << std::endl;
	std::cin >> aC1o;

	//Algoritmo para calcular los datos del RFC
	{

		aC1orfc= aC1o.substr(2,3);
		appl=appat.substr(0,1);
		apsl=appat.substr(1,1);
		aptl=appat.substr(2,1);
		apcl=appat.substr(3,1);
		apql=appat.substr(4,1);
		aml=apmat.substr(0,1);
		pnl=pnombre.substr(0,1);
		snl=snombre.substr(0,1);

		//Este comando busca la primer vocal del apellido paterno
		if (apsl=="a") {
			apv=apsl;
		} else if (apsl=="e") {
			apv=apsl;
		} else if (apsl=="i") {
			apv=apsl;
		} else if (apsl=="o") {
			apv=apsl;
		} else if (apsl=="u") {
			apv=apsl;
		}

		else if (aptl=="a") {
			apv=aptl;
		} else if (aptl=="e") {
			apv=aptl;
		} else if (aptl=="i") {
			apv=aptl;
		} else if (aptl=="o") {
			apv=aptl;
		} else if (aptl=="u") {
			apv=aptl;
		}

		else if (apcl=="a") {
			apv=apcl;
		} else if (apcl=="e") {
			apv=apcl;
		} else if (apcl=="i") {
			apv=apcl;
		} else if (apcl=="o") {
			apv=apcl;
		} else if (apcl=="u") {
			apv=apcl;
		}

		else if (apql=="a") {
			apv=apql;
		} else if (apql=="e") {
			apv=apql;
		} else if (apql=="i") {
			apv=apql;
		} else if (apql=="o") {
			apv=apql;
		} else if (apql=="u") {
			apv=apql;
		} else {
			apv="x";
		}

	}

	//Conversion de letra para casos de segundo nombre
	{
		if (pnombre== "jose") {
			nombrerfc=snl;
		} else if (pnombre== "JOSE") {
			nombrerfc=snl;
		} else if (pnombre== "Jose") {
			nombrerfc=snl;
		} else if (pnombre== "J") {
			nombrerfc=snl;
		} else if (pnombre== "j") {
			nombrerfc=snl;
		} else {
			nombrerfc=pnl;
		}


		if (pnombre== "maria") {
			nombrerfc=snl;
		} else if (pnombre== "MARIA") {
			nombrerfc=snl;
		} else if (pnombre== "Maria") {
			nombrerfc=snl;
		} else if (pnombre== "MA") {
			nombrerfc=snl;
		} else if (pnombre== "ma") {
			nombrerfc=snl;
		} else if (pnombre== "Ma") {
			nombrerfc=snl;
		} else if (pnombre== "M") {
			nombrerfc=snl;
		} else if (pnombre== "m") {
			nombrerfc=snl;
		} else {
			nombrerfc=pnl;
		}
	}

	//Estes comando combina todos los datos para el RFC
	letras=appl+apv+aml+nombrerfc;

	//Listado de palabras inconvenientes
	{
		if (letras=="pene")
		{
			letrasrfc="PENX";
		} else if (letras=="asno")
		{
			letrasrfc="ASNX";
		} else if (letras=="baca")
		{
			letrasrfc="BACx";
		} else if (letras=="baka")
		{
			letrasrfc="BAKx";
		} else if (letras=="buei")
		{
			letrasrfc="BUEx";
		} else if (letras=="buey")
		{
			letrasrfc="buex";
		} else if (letras=="caca")
		{
			letrasrfc="cacx";
		} else if (letras=="caco")
		{
			letrasrfc="cacx";
		} else if (letras=="caga")
		{
			letrasrfc="cagx";
		} else if (letras=="cago")
		{
			letrasrfc="cagx";
		} else if (letras=="caka")
		{
			letrasrfc="cakx";
		} else if (letras=="cako")
		{
			letrasrfc="cakx";
		} else if (letras=="coge")
		{
			letrasrfc="cogx";
		} else if (letras=="cogi")
		{
			letrasrfc="cogx";
		} else if (letras=="coja")
		{
			letrasrfc="cojx";
		} else if (letras=="asno")
		{
			letrasrfc="ASNX";
		} else if (letras=="coje")
		{
			letrasrfc="cojx";
		} else if (letras=="coji")
		{
			letrasrfc="cojx";
		} else if (letras=="cojo")
		{
			letrasrfc="cojx";
		} else if (letras=="cola")
		{
			letrasrfc="colx";
		} else if (letras=="culo")
		{
			letrasrfc="culx";
		} else if (letras=="falo")
		{
			letrasrfc="falx";
		} else if (letras=="feto")
		{
			letrasrfc="fetx";
		} else if (letras=="geta")
		{
			letrasrfc="getx";
		} else if (letras=="guei")
		{
			letrasrfc="guex";
		} else if (letras=="guey")
		{
			letrasrfc="guex";
		} else if (letras=="jeta")
		{
			letrasrfc="jetx";
		} else if (letras=="joto")
		{
			letrasrfc="jotx";
		} else if (letras=="kaca")
		{
			letrasrfc="kacx";
		} else if (letras=="kaco")
		{
			letrasrfc="kacx";
		} else if (letras=="kaga")
		{
			letrasrfc="kagx";
		} else if (letras=="kago")
		{
			letrasrfc="kagx";
		} else if (letras=="kaka")
		{
			letrasrfc="kakx";
		} else if (letras=="kako")
		{
			letrasrfc="kakx";
		} else if (letras=="koge")
		{
			letrasrfc="kogx";
		} else if (letras=="kogi")
		{
			letrasrfc="kogx";
		} else if (letras=="koja")
		{
			letrasrfc="kojx";
		} else if (letras=="koje")
		{
			letrasrfc="kojx";
		} else if (letras=="koji")
		{
			letrasrfc="kojx";
		} else if (letras=="kojo")
		{
			letrasrfc="kojx";
		} else if (letras=="kola")
		{
			letrasrfc="kolx";
		} else if (letras=="kulo")
		{
			letrasrfc="kulx";
		} else if (letras=="lilo")
		{
			letrasrfc="lilx";
		} else if (letras=="loca")
		{
			letrasrfc="locx";
		} else if (letras=="loco")
		{
			letrasrfc="locx";
		} else if (letras=="loka")
		{
			letrasrfc="lokx";
		} else if (letras=="loko")
		{
			letrasrfc="lokx";
		} else if (letras=="mame")
		{
			letrasrfc="mamx";
		} else if (letras=="mamo")
		{
			letrasrfc="mamx";
		} else if (letras=="mear")
		{
			letrasrfc="meax";
		} else if (letras=="meas")
		{
			letrasrfc="meax";
		} else if (letras=="miar")
		{
			letrasrfc="miax";
		} else if (letras=="meon")
		{
			letrasrfc="meox";
		} else if (letras=="mion")
		{
			letrasrfc="miox";
		} else if (letras=="moco")
		{
			letrasrfc="mocx";
		} else if (letras=="moko")
		{
			letrasrfc="mokx";
		} else if (letras=="mula")
		{
			letrasrfc="mulx";
		} else if (letras=="mulo")
		{
			letrasrfc="mulx";
		} else if (letras=="naca")
		{
			letrasrfc="nacx";
		} else if (letras=="naco")
		{
			letrasrfc="nacx";
		} else if (letras=="peda")
		{
			letrasrfc="pedx";
		} else if (letras=="pedo")
		{
			letrasrfc="pedx";
		} else if (letras=="pipi")
		{
			letrasrfc="pipx";
		} else if (letras=="pito")
		{
			letrasrfc="pitx";
		} else if (letras=="popo")
		{
			letrasrfc="popx";
		} else if (letras=="puta")
		{
			letrasrfc="putx";
		} else if (letras=="puto")
		{
			letrasrfc="putx";
		} else if (letras=="qulo")
		{
			letrasrfc="qulx";
		} else if (letras=="rata")
		{
			letrasrfc="ratx";
		} else if (letras=="roba")
		{
			letrasrfc="robx";
		} else if (letras=="robe")
		{
			letrasrfc="robx";
		} else if (letras=="robo")
		{
			letrasrfc="robx";
		} else if (letras=="ruin")
		{
			letrasrfc="ruix";
		} else if (letras=="seno")
		{
			letrasrfc="senx";
		} else if (letras=="teta")
		{
			letrasrfc="tetx";
		} else if (letras=="vaca")
		{
			letrasrfc="vacx";
		} else if (letras=="vaga")
		{
			letrasrfc="vagx";
		} else if (letras=="vago")
		{
			letrasrfc="vagx";
		} else if (letras=="vaka")
		{
			letrasrfc="vakx";
		} else if (letras=="vuei")
		{
			letrasrfc="vuex";
		} else if (letras=="vuey")
		{
			letrasrfc="vuex";
		} else if (letras=="wuei")
		{
			letrasrfc="wuex";
		} else if (letras=="wuey")
		{
			letrasrfc="wuex";
		} else
		{
			letrasrfc=letras;
		}
	}

	std::transform(letrasrfc.begin(), letrasrfc.end(), letrasrfc.begin(), ::toupper);

	std::cout << "Su RFC es: " << letrasrfc << aC1orfc << mes << dia << std::endl;
}
