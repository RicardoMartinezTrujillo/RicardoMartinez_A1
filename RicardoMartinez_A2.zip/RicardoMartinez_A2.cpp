#include <iostream> //Actividad 2 por Ricardo Martinez

int main()
{
    float numero1, numero2;
    //Declaramos como numeros reales a los numeros que ingresaremos
    std::cout << "Ingresa el primer numero:" << std::endl;
    std::cin >> numero1;
    //Este comando mos permite ingresar el primer numero
    std::cout << "Ingresa el segundo numero:" << std::endl;
    std::cin >> numero2;
    //Ingresamos tambien el segundo numero
    
    float suma, resta, mpon, dvon;
    //Declaramos como numero real los resultados de cada operación 
    suma= numero1+numero2;
    resta= numero1-numero2;
    mpon= numero1*numero2;
    dvon= numero1/numero2;
    //Estas son las respectivas operaciones que realizamos
    std::cout << "" << std::endl;
    std::cout << "La suma es: " << suma << std::endl;
    std::cout << "La resta es: " << resta << std::endl;
    std::cout << "La multiplicación es: " << mpon << std::endl;
    std::cout << "La división es: " << dvon << std::endl;
    //Con estos comandos el código arroja los resultados con su respectiva oración
    
    return 0;
}